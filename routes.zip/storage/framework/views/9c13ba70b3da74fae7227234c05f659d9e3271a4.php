<?php $__env->startSection('title'); ?><?php echo e($title ?? ''); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('contentIndex'); ?>
    <div class="AdminApp"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/brayan/Laravel/ordersApp/resources/views/adminApp.blade.php ENDPATH**/ ?>