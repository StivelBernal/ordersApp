<div class="headerContainer" id="headerContainer" >
  <header id="fix-header-container-static" class="fix-header-container">

    <nav class="fix-header-container-primary">

      <div class="fix-header-container-primary-content">

        <div class="fix-header-logo">
          <a href="/">
            <img src="/assets/logo.png" alt="Logo" />
          </a>
        </div>

        <div class="menu-container">
            
          <ul class="fixperto-primary-menu">
            <li>
              <a href="/home">Inicio</a>
            </li>
            <li>
              <a href="/">Consultar pedidos</a>
            </li>
          </ul>
      
        </div>

      </div>


    </nav> 


  </header>

</div><?php /**PATH /home/brayan/Laravel/ordersApp/resources/views/partials/header.blade.php ENDPATH**/ ?>