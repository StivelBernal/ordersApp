<footer>
    <div class="links-footer">
      <a href="https://github.com/StivelBernal/pruebaTecnica" target="_blank">Link del Repositorio</a>
    </div>
</footer><?php /**PATH /home/brayan/Laravel/ordersApp/resources/views/partials/footer.blade.php ENDPATH**/ ?>