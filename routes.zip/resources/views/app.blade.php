@extends('layouts.index')

@section('title'){{ $title ?? '' }}@endsection

@section('contentIndex')
    <div class="ClientApp"></div>
@endsection