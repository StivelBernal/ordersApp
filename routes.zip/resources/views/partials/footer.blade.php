<footer>
    <div class="links-footer">
      <a href="https://github.com/StivelBernal/pruebaTecnica" target="_blank">Link del Repositorio</a>
    </div>
</footer>