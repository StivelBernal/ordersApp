// inicializa las aplicaciones react de admin y la de consulta de pedidos
import './src/App.tsx'

// Agrega iconos svg al documento
import './icons.ts'

